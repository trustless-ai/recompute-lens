# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: browser.spec.mjs >> raw bytes, 4 MiB and depth admission controls
- Location: tests\agent-anchor\browser.spec.mjs:52:1

# Error details

```
Error: RAW_EXACT_4MIB

expect(received).toBe(expected) // Object.is equality

Expected: "ADMITTED"
Received: "Maximum call stack size exceeded"
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | import { readFileSync, mkdirSync, writeFileSync } from 'node:fs';
  3  | import { resolve } from 'node:path';
  4  | import { createHash } from 'node:crypto';
  5  | import { admissionCases } from './admission-cases.mjs';
  6  | const fixture=name=>JSON.parse(readFileSync(new URL('./fixtures/'+name,import.meta.url)));
  7  | const kit=fixture('kit-vectors.json'), extra=fixture('browser-vectors.json'),slots=fixture('slot-vectors.json');
  8  | const all=[...kit.vectors,...extra.vectors];
  9  | const report={schema:'lens.chromium-conformance.v0',goldens:{},results:{},slot_results:{},admission:{},ui:[]};
  10 | const out=resolve(process.env.LENS_REPORT_DIR||'build/agent-anchor/browser');
  11 | test.beforeEach(async ({page})=>{
  12 |   const external=[],errors=[];
  13 |   page.on('request',r=>{if(!r.url().startsWith('http://127.0.0.1:4173/'))external.push(r.url());});
  14 |   page.on('pageerror',e=>errors.push(e.message));
  15 |   await page.goto('/tests/agent-anchor/harness.html');
  16 |   await page.waitForFunction(()=>!!window.lensTest);
  17 |   page.lensExternal=external;page.lensErrors=errors;
  18 | });
  19 | test.afterEach(async ({page})=>{expect(page.lensExternal).toEqual([]);expect(page.lensErrors).toEqual([]);});
  20 | test.afterAll(async ({browser})=>{
  21 |   mkdirSync(out,{recursive:true});
  22 |   writeFileSync(resolve(out,'browser-results.json'),JSON.stringify(report,null,2)+'\n');
  23 |   writeFileSync(resolve(out,'browser-runtime.json'),JSON.stringify({browser:browser.version(),platform:process.platform,node:process.version},null,2)+'\n');
  24 | });
  25 | test('all existing and new golden recipes execute in Chromium',async ({page})=>{
  26 |   const got=await page.evaluate(async()=>{
  27 |     const result={};
  28 |     for(const r of window.lensTest.RECIPES)result[r.id]={selfTest:await r.selfTest(),example:await r.run(r.loadExample())};
  29 |     return result;
  30 |   });
  31 |   expect(Object.keys(got)).toHaveLength(16);
  32 |   for(const [id,result] of Object.entries(got)){expect(result.selfTest.ok,id).toBe(true);expect(result.example).not.toHaveProperty('error');}
  33 |   report.goldens=got;
  34 | });
  35 | test('complete upstream and browser-specific result projections match independent expectations',async ({page})=>{
  36 |   // Only input + separate context cross the browser boundary; no expected outcome.
  37 |   const got=await page.evaluate(async vectors=>{
  38 |     const result={};for(const v of vectors)result[v.name]=await window.lensTest.evaluateProof(v.input,v.context);return result;
  39 |   },all.map(({name,input,context})=>({name,input,context})));
  40 |   for(const v of all)expect(got[v.name],v.name).toEqual(v.expected);
  41 |   report.results=got;
  42 | });
  43 | test('original native slot-log vectors and exact header roots',async ({page})=>{
  44 |   const got=await page.evaluate(async vectors=>{
  45 |     const result={};
  46 |     for(const v of vectors){try{const r=await window.lensTest.checkFile(v.file);if(v.prev!=null)await window.lensTest.checkChain(r.header,r.lines,v.prev);result[v.id]={status:'ok',root:r.root};}catch{result[v.id]={status:'reject'};}}
  47 |     return result;
  48 |   },slots.vectors.map(({id,file,prev})=>({id,file,prev})));
  49 |   for(const v of slots.vectors)expect(got[v.id],v.id).toEqual(v.expect==='ok'?{status:'ok',root:v.log_root}:{status:'reject'});
  50 |   report.slot_results=got;
  51 | });
  52 | test('raw bytes, 4 MiB and depth admission controls',async ({page})=>{
  53 |   for(const v of admissionCases(new Uint8Array(Buffer.from(kit.vectors[0].input.subject_base64,'base64')))){
  54 |     const got=await page.evaluate(async b64=>{try{return {status:'ADMITTED',id:await window.lensTest.admitSubject(window.lensTest.fromBase64(b64))};}catch(e){return {status:e.code||e.message};}},Buffer.from(v.raw).toString('base64'));
> 55 |     expect(got.status,v.name).toBe(v.expected);
     |                               ^ Error: RAW_EXACT_4MIB
  56 |     if(got.status==='ADMITTED')expect(got.id).toBe('0x'+createHash('sha256').update(v.raw).digest('hex'));
  57 |     report.admission[v.name]=got;
  58 |   }
  59 | });
  60 | test('UI exposes dimensions, preserves raw file bytes and never adopts host or proof trust',async ({page})=>{
  61 |   await page.goto('/');
  62 |   for(const profile of ['agent-action.subject-record.v0','receiptos.manifest-proof.v0','invinoveritas.decision_receipt.slot_log.v1']){
  63 |     await page.locator('.recipe-pick').selectOption(profile);await page.getByRole('button',{name:'Load example'}).click();await page.getByRole('button',{name:'Recompute',exact:true}).click();
  64 |     const dims=page.getByTestId('result-dimensions');await expect(dims).toContainText('Proof validity: VERIFIED');
  65 |     await expect(dims).toContainText('ANCHORED_VERIFIED — NOT_COVERED');await expect(page.locator('.v-badge')).toHaveCount(0);
  66 |     report.ui.push({case:profile,dimensions:true});
  67 |   }
  68 |   await page.locator('.recipe-pick').selectOption('receiptos.manifest-proof.v0');await page.getByRole('button',{name:'Load example'}).click();
  69 |   await page.locator('#field-host').fill(JSON.stringify({...kit.vectors[0].expected,proof_validity:'REFUTED'}));
  70 |   await page.getByRole('button',{name:'Recompute',exact:true}).click();await expect(page.getByTestId('result-dimensions')).toContainText('DISAGREEMENT');await expect(page.getByTestId('result-dimensions')).toContainText('Proof validity: VERIFIED');
  71 |   report.ui.push({case:'host-disagreement',browser_result_retained:true});
  72 |   const broken=kit.vectors.find(v=>v.name==='CORRUPT_SIBLING');
  73 |   await page.locator('#field-envelope').fill(Buffer.from(broken.input.envelope_base64,'base64').toString());
  74 |   await page.locator('#field-host').fill(JSON.stringify(kit.vectors[0].expected));await page.getByRole('button',{name:'Recompute',exact:true}).click();
  75 |   await expect(page.getByTestId('result-dimensions')).toContainText('Proof validity: REFUTED');report.ui.push({case:'host-cannot-override-broken-proof',refuted:true});
  76 |   await page.locator('#field-configuration').fill('{}');await page.getByRole('button',{name:'Recompute',exact:true}).click();await expect(page.getByTestId('result-dimensions')).toContainText('Proof validity: UNVERIFIABLE');report.ui.push({case:'configuration-required',unverifiable:true});
  77 |   await page.locator('.recipe-pick').selectOption('agent-action.subject-record.v0');await page.getByRole('button',{name:'Load example'}).click();
  78 |   await page.getByLabel('Original bytes file: subject',{exact:true}).setInputFiles({name:'invalid.json',mimeType:'application/json',buffer:Buffer.from([0xc0,0xaf])});
  79 |   await page.getByRole('button',{name:'Recompute',exact:true}).click();await expect(page.getByTestId('result-dimensions')).toContainText('INVALID_UTF8');report.ui.push({case:'original-file-invalid-utf8',refused:true});
  80 |   await page.screenshot({path:resolve(out,'raw-byte-refusal.png'),fullPage:true});
  81 | });
  82 | 
```