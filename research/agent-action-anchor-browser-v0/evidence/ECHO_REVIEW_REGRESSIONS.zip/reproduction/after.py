import hashlib,json,os,shutil,subprocess
from pathlib import Path
out=Path(__file__).resolve().parent
source=Path('C:/Users/msi/Documents/Codex/recompute-lens-agent-anchor-v0')
repo=out.parent/'echo-after-removal'; logs=out/'after-removal'; logs.mkdir()
subprocess.run(['git','-c','core.autocrlf=false','clone','--no-hardlinks',str(source),str(repo)],check=True,capture_output=True)
names=sorted(set(subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=source).decode().split('\0'))-{''})
for n in names:
 dst=repo/n;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes((source/n).read_bytes())
records=[]
def run(name,args,want=0):
 p=subprocess.run(args,cwd=repo,capture_output=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONUTF8':'1'})
 for stream in ['stdout','stderr']:(logs/(name+'.'+stream)).write_bytes(getattr(p,stream))
 records.append({'name':name,'argv':args,'exit':p.returncode});(logs/'commands.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf8',newline='\n')
 print(name,p.returncode,flush=True)
 if p.returncode!=want:raise RuntimeError(name)
 return p
run('install',[shutil.which('npm.cmd'),'ci','--ignore-scripts','--no-audit','--no-fund'])
file=repo/'src/recompute/agent-anchor/manifest.js';original=file.read_bytes()
guard=b"if(new Set(selection.trusted_keys.map(k=>k.id)).size!==selection.trusted_keys.length)throw new Error('AMBIGUOUS_LOG_TRUST_ROOT');"
if original.count(guard)!=1:raise RuntimeError('NOT_APPLIED')
run('guarded-new-conformance',['node','tests/agent-anchor/conformance.mjs'])
try:
 file.write_bytes(original.replace(guard,b'/* isolated duplicate guard removal */'))
 bad=json.loads(run('removed-new-conformance',['node','tests/agent-anchor/conformance.mjs'],1).stdout)
 if [x['name'] for x in bad['failures']]!=['REVIEW_DUPLICATE_KEY_ATTACKER_FIRST','REVIEW_DUPLICATE_KEY_ATTACKER_SECOND']:raise RuntimeError('Wrong reason')
 if bad['failures'][0]['actual']['proof_validity']!='VERIFIED':raise RuntimeError('No semantic witness')
finally:file.write_bytes(original)
run('restored-new-conformance',['node','tests/agent-anchor/conformance.mjs'])
if any((repo/n).read_bytes()!=(source/n).read_bytes() for n in names):raise RuntimeError('RESTORATION_FAILED')
(logs/'summary.json').write_text(json.dumps({'guard_applied_once':True,'healthy_exit':0,'removed_exit':1,'restored_exit':0,'new_failures':[x['name'] for x in bad['failures']],'crash':False,'all_candidate_source_bytes_restored':len(names),'manifest_sha256':hashlib.sha256(original).hexdigest()},indent=2)+'\n',encoding='utf8',newline='\n')
