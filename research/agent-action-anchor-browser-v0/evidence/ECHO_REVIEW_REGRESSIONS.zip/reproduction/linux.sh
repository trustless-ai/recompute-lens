set -eu
export PATH=/home/msi/codex-audits/issue79-eedod_7c/venv/bin:/usr/local/bin:/usr/bin:/bin
export PYTHONDONTWRITEBYTECODE=1
export PYTHONUTF8=1
OUT='/mnt/d/PAVLO HQ/Workspaces/recompute-lens-browser-recipes-v0/echo-review-20261023'
SOURCE='/mnt/c/Users/msi/Documents/Codex/recompute-lens-agent-anchor-v0'
TASKROOT=$(mktemp -d /home/msi/codex-audits/lens-echo-review.XXXXXX)
printf %s "$TASKROOT" > "$OUT/linux-path.txt"
git -c core.autocrlf=false clone -q --no-checkout "$SOURCE" "$TASKROOT/repo"
git -C "$TASKROOT/repo" checkout --detach 84cf444537f9fdc028c355a830790fa80597f4aa
tar -xf "$OUT/candidate-files.tar" -C "$TASKROOT/repo"
cd "$TASKROOT/repo"
mkdir -p build/agent-anchor
cp -a /home/msi/codex-audits/recompute-lens-agent-anchor-v0-84cf444/build/agent-anchor/upstream build/agent-anchor/upstream
npm ci --ignore-scripts --no-audit --no-fund > "$OUT/linux-install.stdout" 2> "$OUT/linux-install.stderr"
python3 -O -B tests/agent-anchor/validate.py --out build/echo-review-linux
git diff --check
