import hashlib,json,os,shutil,subprocess
from pathlib import Path
out=Path(__file__).resolve().parent;repo=out.parent/'echo-before';author=Path('C:/Users/msi/Documents/Codex/recompute-lens-agent-anchor-v0')
logs=out/'before';logs.mkdir();records=[]
def run(name,args,want=0):
 p=subprocess.run(args,cwd=repo,capture_output=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONUTF8':'1'})
 (logs/(name+'.stdout')).write_bytes(p.stdout);(logs/(name+'.stderr')).write_bytes(p.stderr)
 records.append({'name':name,'argv':list(map(str,args)),'exit':p.returncode});(logs/'commands.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf8',newline='\n')
 print(name,p.returncode,flush=True)
 if p.returncode!=want:raise RuntimeError(name)
 return p
run('install',[shutil.which('npm.cmd'),'ci','--ignore-scripts','--no-audit','--no-fund'])
file=repo/'src/recompute/agent-anchor/manifest.js';original=file.read_bytes()
guard=b"if(new Set(selection.trusted_keys.map(k=>k.id)).size!==selection.trusted_keys.length)throw new Error('AMBIGUOUS_LOG_TRUST_ROOT');"
assert original.count(guard)==1
probe=['node',str(out/'probe.mjs'),str(repo/'src/recompute/agent-anchor/proof.js'),str(author/'tests/agent-anchor/fixtures/review-regressions-v0.json')]
run('guarded-old-conformance',['node','tests/agent-anchor/conformance.mjs'])
good=json.loads(run('guarded-new-probes',probe).stdout);assert not good['mismatches']
try:
 file.write_bytes(original.replace(guard,b'/* isolated duplicate guard removal */'))
 run('removed-old-conformance',['node','tests/agent-anchor/conformance.mjs'])
 run('removed-old-mutations',['node','tests/agent-anchor/mutations.mjs','--out','build/echo-removed-old'])
 bad=json.loads(run('removed-new-probes',probe).stdout)
 assert bad['results']['REVIEW_DUPLICATE_KEY_ATTACKER_FIRST']['proof_validity']=='VERIFIED'
 assert bad['results']['REVIEW_DUPLICATE_KEY_ATTACKER_SECOND']['reason']=='CHECKPOINT_SIGNATURE_INVALID'
 assert bad['mismatches']==['REVIEW_DUPLICATE_KEY_ATTACKER_FIRST','REVIEW_DUPLICATE_KEY_ATTACKER_SECOND']
finally:file.write_bytes(original)
control=b'if(!await verifyEd25519(base64(selected.public_key_spki_base64),base64(c.signature_base64),checkpointBytes(c.body)))'
assert original.count(control)==1
try:
 file.write_bytes(original.replace(control,b'if(false)'))
 p=run('known-checkpoint-signature-control',['node','tests/agent-anchor/conformance.mjs'],1)
 assert b'INVALID_CHECKPOINT_SIGNATURE' in p.stdout
finally:file.write_bytes(original)
run('restored-old-conformance',['node','tests/agent-anchor/conformance.mjs'])
assert file.read_bytes()==original
assert subprocess.check_output(['git','status','--porcelain'],cwd=repo)==b''
(logs/'summary.json').write_text(json.dumps({'reviewed_head':'84cf444537f9fdc028c355a830790fa80597f4aa','duplicate_guard_applied_once':True,'old_conformance_and_mutations_miss_removal':True,'attacker_first_without_guard':'VERIFIED','attacker_second_without_guard':'REFUTED / CHECKPOINT_SIGNATURE_INVALID','correct_policies_authenticated_separately':True,'known_signature_mutation_control_exit':1,'restoration_sha256':hashlib.sha256(original).hexdigest(),'git_status_porcelain':''},indent=2)+'\n',encoding='utf8',newline='\n')
