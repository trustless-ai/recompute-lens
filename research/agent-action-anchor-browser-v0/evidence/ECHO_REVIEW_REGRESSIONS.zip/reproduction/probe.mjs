import { pathToFileURL } from 'node:url';
import { readFileSync } from 'node:fs';
import { isDeepStrictEqual } from 'node:util';
const mod=await import(pathToFileURL(process.argv[2]));
const corpus=JSON.parse(readFileSync(process.argv[3]));const results={},mismatches=[];
for(const v of corpus.vectors){const r=await mod.evaluateProof(v.input,v.context);results[v.name]=r;if(!isDeepStrictEqual(r,v.expected))mismatches.push(v.name);}
console.log(JSON.stringify({results,mismatches},null,2));
